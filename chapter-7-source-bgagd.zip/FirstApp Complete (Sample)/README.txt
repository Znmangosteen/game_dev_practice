This sample project accompanies the book 
"The Beginner's Guide to Android Game Development" by James S. Cho.

For more information, please see:
jamescho7.com/book